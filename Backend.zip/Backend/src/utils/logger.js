import { existsSync, mkdirSync } from 'fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import winston from 'winston';
import winstonDaily from 'winston-daily-rotate-file';
import { LOG_DIR } from '../config/index.js';
// Get current dir name
// const __dirname = import.meta.dirname;
const __dirname = dirname(fileURLToPath(import.meta.url));
// Log dir
const logDir = join(__dirname, '../../', LOG_DIR || '');
// Create Log dir if it doesn't exists
if (!existsSync(logDir)) {
    mkdirSync(logDir);
}
// Define log format
const logFormat = winston.format.printf(({ timestamp, level, message }) => `${timestamp} ${level}: ${message}`);
/*
 * Log Level
 * error: 0, warn: 1, info: 2, http: 3, verbose: 4, debug: 5, silly: 6
 */
const logger = winston.createLogger({
    format: winston.format.combine(winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss',
    }), logFormat),
    transports: [
        // debug log setting
        new winstonDaily({
            level: 'debug',
            datePattern: 'YYYY-MM-DD',
            // log file /logs/debug/*.log in save
            dirname: logDir + '/debug',
            filename: '%DATE%.log',
            // 30 Days saved
            maxFiles: 30,
            json: false,
            zippedArchive: true,
        }),
        // error log setting
        new winstonDaily({
            level: 'error',
            datePattern: 'YYYY-MM-DD',
            // log file /logs/error/*.log in save
            dirname: logDir + '/error',
            filename: '%DATE%.log',
            // 30 Days saved
            maxFiles: 30,
            handleExceptions: true,
            json: false,
            zippedArchive: true,
        }),
    ],
});
logger.add(new winston.transports.Console({
    format: winston.format.combine(winston.format.splat(), winston.format.colorize()),
}));
const stream = {
    write: (message) => {
        logger.info(message.substring(0, message.lastIndexOf('\n')));
    },
};
export { logger, stream };
